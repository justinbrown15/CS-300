//Name: Justin Brown
//Course: CS 300
//Project: Project #2

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>
#include <algorithm>

using namespace std;

class Course {
public:
    //to hold the coursenumber from line
    string courseNum;

    //to hold the course name from the line
    string name;

    //strings to hold the prerequisites
    string preReeks;
    string preRequisite1;
    string preRequisite2;
};
//vector to hold the courses
vector <Course> course;

//function to sort the courses alphanumerically
bool compareCourses(const Course& course1, const Course& course2) {
    return course1.courseNum.compare(course2.courseNum) <= 0;
}
//iterate through the file and populate the course vector with the different components
void separateLines() {
    fstream file;
    string line;
    file.open("ABCU.txt");
    while (getline(file, line)) {
        stringstream ss(line);
        Course c;
        getline(ss, c.courseNum, ',');
        getline(ss, c.name, ',');
        getline(ss, c.preReeks, ',');
        getline(ss, c.preRequisite1, ',');
        course.push_back(c);
    }
    sort(course.begin(), course.end(), compareCourses);
}
//open and read the file
void readWholeFile() {
    fstream file;
    string text;
    file.open("ABCU.txt");
    if (file.is_open()) {
        while (file.good()) {
            //get each line
            getline(file, text);
            

        }
    }
}
//iterate through the vector and print the course number and name
void printCourseList() {
    for (int i = 0; i < course.size(); i++) {
        cout << course[i].courseNum << ", " << course[i].name << endl;
    }
}
//check to see if the user entered string equals any courses in the vector and print out information
void printCourse() {
    string userCourse;
   cout << "what course do you want to know about? " << endl;
   cin >> userCourse;
   for (int i = 0; i < course.size(); i++) {
       if (userCourse.compare(course[i].courseNum)==0) {
           cout << course[i].courseNum << ", " << course[i].name << endl;
           cout << "Prerequisites: " << course[i].preReeks << ",";
           cout << course[i].preRequisite1 << endl;


       }
   }
}

int main()
{
    //variables to hold the user choices
    int userChoice;
    string userCourse;
    cout << "Welcome to the course planner." << endl;
    
   //do-while loop to keep looping through until user breaks
    do {
        cout << endl;
        cout << "1. Load Data Structure." << endl;
        cout << "2. Print Course List." << endl;
        cout << "3. Print Course(case-sensitive!)." << endl;
        cout << "4. Exit." << endl;
        cout << endl;
        cout << "What would you like to do? " << endl;
        cin >> userChoice;
        switch (userChoice) {
        case 1:
            separateLines();
            break;
        case 2:
            printCourseList();
            break;
        case 3:
            printCourse();
            break;
        case 4:
            cout << "Thank you for using the course planner!";
            break;
        default:
            cout << "Not a valid option" << endl;
        }
    } while (userChoice != 4); {

    }
}
    




